// Script PannOfficiaL V6

require("./database/module")

//GLOBAL PAYMENT
global.storename = "RiszOfficiaLDeveloper"
global.dana = "082178565011"
global.qris = "-"


// GLOBAL SETTING
global.owner = "6282178565011"
global.namabot = "𝐑𝐢𝐬𝐳𝐜𝐫𝐚𝐬𝐡 𝐨𝐟𝐟𝐢𝐜𝐢𝐚𝐥⃟╳"
global.nomorbot = "628892921845"
global.namaCreator = "💧⃟𝐑𝐢𝐬𝐳𝐜𝐫𝐚𝐬𝐡 𝐨𝐟𝐟𝐢𝐜𝐢𝐚𝐥⃟╳"
global.linkyt = "https://www.youtube.com/@Risz-Hosting" // jgn lupa di subrek  😋😋
global.autoJoin = false
global.antilink = false
global.versisc = '6.0'

// DELAY JPM
global.delayjpm = 5500



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/f4otka.jpg'
global.thumb = 'https://files.catbox.moe/kp3d01.jpg'
global.isLink = "https://whatsapp.com/channel/0029VaxYvF7HVvTX6ZdNRl3M"
global.packname = "Bugs"
global.author = "RiszOfficiaL"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})